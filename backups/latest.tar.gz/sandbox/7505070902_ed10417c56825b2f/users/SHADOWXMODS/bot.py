import os
import sys
import subprocess
import time

# ==================================================
# AUTO-INSTALL MISSING MODULES
# ==================================================

def install_missing_modules():
    """Automatically install required modules if missing"""
    required_modules = ['pyTelegramBotAPI']
    
    for module in required_modules:
        try:
            __import__(module.replace('pyTelegramBotAPI', 'telebot'))
        except ImportError:
            print(f"⚠️ Module '{module}' not found. Installing...")
            try:
                subprocess.check_call([sys.executable, "-m", "pip", "install", module])
                print(f"✅ Module '{module}' installed successfully.")
            except Exception as e:
                print(f"❌ Failed to install {module}: {e}")
                sys.exit(1)

# Run auto-install at startup
install_missing_modules()

# ==================================================
# NOW IMPORT TELEBOT
# ==================================================

import telebot
import zipfile
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton

# ==================================================
# CONFIG
# ==================================================

BOT_TOKEN = "8755062401:AAGqz8RooBKuYNvqPxdttrEt-bO4Symcqc8"
ADMIN_ID = 7505070902

# ==================================================
# ROOT DIRECTORY
# ==================================================

ROOT_DIR = "/"

# ==================================================
# BOT
# ==================================================

bot = telebot.TeleBot(BOT_TOKEN)

try:
    bot.remove_webhook()
except Exception as e:
    print(e)

print("🤖 FILE MANAGER BOT STARTED")
print(f"📂 ROOT DIRECTORY: {ROOT_DIR}")

# ==================================================
# FORMAT FILE SIZE
# ==================================================

def format_size(size):
    try:
        for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
            if size < 1024:
                return f"{size:.1f} {unit}"
            size /= 1024
        return "Unknown"
    except:
        return "Unknown"

# ==================================================
# SAFE PATH
# ==================================================

def safe_path(path):
    try:
        return os.path.exists(path)
    except:
        return False

# ==================================================
# ZIP ENTIRE DIRECTORY (Recursive) - FIXED
# ==================================================

def zip_entire_directory(folder_path, zip_name="directory.zip"):
    """Create ZIP of entire directory with timestamp fix"""
    zip_path = f"/tmp/{zip_name}"
    
    try:
        with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(folder_path):
                for file in files:
                    full_path = os.path.join(root, file)
                    rel_path = os.path.relpath(full_path, folder_path)
                    
                    try:
                        # Try to write file
                        zipf.write(full_path, rel_path)
                    except ValueError:
                        # Timestamp error - skip this file
                        print(f"Skipping file due to timestamp: {rel_path}")
                        continue
                    except Exception as e:
                        # Other errors - skip
                        print(f"Skipping file {rel_path}: {e}")
                        continue
        
        # Check if zip has content
        if os.path.getsize(zip_path) < 100:  # Less than 100 bytes
            os.remove(zip_path)
            raise Exception("No files could be zipped")
            
        return zip_path
        
    except Exception as e:
        # Clean up on error
        if os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except:
                pass
        raise e

# ==================================================
# BUILD MENU
# ==================================================

def build_menu(current_path):
    markup = InlineKeyboardMarkup(row_width=1)

    try:
        items = sorted(os.listdir(current_path))
    except Exception as e:
        print(f"ERROR: {e}")
        return markup

    # BACK BUTTON
    if os.path.realpath(current_path) != os.path.realpath(ROOT_DIR):
        parent = os.path.dirname(current_path)
        markup.add(
            InlineKeyboardButton(
                "🔙 BACK",
                callback_data=f"open|{parent}"
            )
        )

    # DOWNLOAD ENTIRE DIRECTORY BUTTON
    markup.add(
        InlineKeyboardButton(
            "📦 DOWNLOAD ENTIRE DIRECTORY",
            callback_data=f"zipall|{current_path}"
        )
    )

    # DOWNLOAD ALL FILES ONLY BUTTON
    files_count = sum(1 for item in items if os.path.isfile(os.path.join(current_path, item)))
    if files_count > 0:
        markup.add(
            InlineKeyboardButton(
                f"⬇️ DOWNLOAD ALL FILES ONLY ({files_count})",
                callback_data=f"zipfiles|{current_path}"
            )
        )

    folders = []
    files = []

    for item in items:
        full_path = os.path.join(current_path, item)
        if not safe_path(full_path):
            continue
        try:
            if os.path.isdir(full_path):
                folders.append((item, full_path))
            else:
                files.append((item, full_path))
        except:
            pass

    # SHOW FOLDERS
    for item, full_path in folders:
        markup.add(
            InlineKeyboardButton(
                f"📂 {item}",
                callback_data=f"open|{full_path}"
            )
        )

    # SHOW FILES
    for item, full_path in files:
        try:
            size = format_size(os.path.getsize(full_path))
        except:
            size = "Unknown"
        markup.add(
            InlineKeyboardButton(
                f"📄 {item} ({size})",
                callback_data=f"file|{full_path}"
            )
        )

    return markup

# ==================================================
# START COMMAND
# ==================================================

@bot.message_handler(commands=['start'])
def start(message):
    if message.from_user.id != ADMIN_ID:
        bot.reply_to(message, "❌ Access Denied")
        return

    markup = build_menu(ROOT_DIR)
    text = (
        "📂 FILE MANAGER\n\n"
        f"🌍 ROOT:\n{ROOT_DIR}\n\n"
        "Browse files using buttons below.\n\n"
        "📦 **DOWNLOAD ENTIRE DIRECTORY** - Zip & download everything (files + subfolders)\n"
        "⬇️ **DOWNLOAD ALL FILES ONLY** - Zip & download only files in current folder"
    )
    bot.send_message(
        message.chat.id,
        text,
        reply_markup=markup
    )

# ==================================================
# SEARCH COMMAND
# ==================================================

@bot.message_handler(commands=['find'])
def find_file(message):
    if message.from_user.id != ADMIN_ID:
        bot.reply_to(message, "❌ Access Denied")
        return

    try:
        filename = message.text.split(" ", 1)[1]
    except:
        bot.reply_to(
            message,
            "❌ Usage:\n/find bot.py"
        )
        return

    searching_msg = bot.reply_to(
        message,
        f"🔍 Searching:\n{filename}"
    )

    found_files = []
    for root, dirs, files in os.walk(ROOT_DIR):
        try:
            for file in files:
                if file.lower() == filename.lower():
                    full_path = os.path.join(root, file)
                    found_files.append(full_path)
        except:
            pass

    if not found_files:
        bot.edit_message_text(
            f"❌ File not found:\n{filename}",
            message.chat.id,
            searching_msg.message_id
        )
        return

    markup = InlineKeyboardMarkup(row_width=1)
    for path in found_files[:50]:
        short_name = os.path.basename(path)
        markup.add(
            InlineKeyboardButton(
                f"📄 {short_name}",
                callback_data=f"file|{path}"
            )
        )

    bot.edit_message_text(
        f"✅ Found {len(found_files)} file(s)\n\n🔍 {filename}",
        message.chat.id,
        searching_msg.message_id,
        reply_markup=markup
    )

# ==================================================
# CALLBACK HANDLER
# ==================================================

@bot.callback_query_handler(func=lambda call: True)
def callback_handler(call):
    if call.from_user.id != ADMIN_ID:
        bot.answer_callback_query(call.id, "❌ Access Denied")
        return

    try:
        action, path = call.data.split("|", 1)
    except:
        return

    if not safe_path(path):
        bot.answer_callback_query(call.id, "❌ Invalid Path")
        return

    # ==================================================
    # OPEN FOLDER
    # ==================================================

    if action == "open":
        markup = build_menu(path)
        try:
            bot.edit_message_text(
                f"📂 PATH:\n{path}",
                call.message.chat.id,
                call.message.message_id,
                reply_markup=markup
            )
        except Exception as e:
            print(e)

    # ==================================================
    # FILE MENU
    # ==================================================

    elif action == "file":
        markup = InlineKeyboardMarkup(row_width=1)
        markup.add(
            InlineKeyboardButton(
                "⬇️ DOWNLOAD",
                callback_data=f"download|{path}"
            )
        )
        markup.add(
            InlineKeyboardButton(
                "🔙 BACK",
                callback_data=f"open|{os.path.dirname(path)}"
            )
        )
        try:
            size = format_size(os.path.getsize(path))
        except:
            size = "Unknown"
        text = (
            f"📄 FILE INFO\n\n"
            f"📌 Name: {os.path.basename(path)}\n"
            f"📦 Size: {size}\n\n"
            f"📂 Path:\n{path}"
        )
        try:
            bot.edit_message_text(
                text,
                call.message.chat.id,
                call.message.message_id,
                reply_markup=markup
            )
        except Exception as e:
            print(e)

    # ==================================================
    # DOWNLOAD FILE
    # ==================================================

    elif action == "download":
        try:
            bot.answer_callback_query(
                call.id,
                "📤 Uploading..."
            )
            with open(path, "rb") as f:
                bot.send_document(
                    call.message.chat.id,
                    f,
                    visible_file_name=os.path.basename(path)
                )
        except Exception as e:
            bot.send_message(
                call.message.chat.id,
                f"❌ ERROR:\n{str(e)}"
            )

    # ==================================================
    # ZIP ENTIRE DIRECTORY (FILES + SUBFOLDERS) - FIXED
    # ==================================================

    elif action == "zipall":
        try:
            bot.answer_callback_query(
                call.id,
                "📦 Creating ZIP of entire directory... Please wait"
            )
            
            folder_name = os.path.basename(path) or "root"
            zip_name = f"{folder_name}_full.zip"
            
            zip_path = zip_entire_directory(path, zip_name)
            
            with open(zip_path, "rb") as f:
                bot.send_document(
                    call.message.chat.id,
                    f,
                    visible_file_name=zip_name
                )
            
            # Cleanup
            os.remove(zip_path)
            
        except Exception as e:
            bot.send_message(
                call.message.chat.id,
                f"❌ ERROR creating ZIP:\n{str(e)}"
            )

    # ==================================================
    # ZIP ALL FILES ONLY (NON-RECURSIVE)
    # ==================================================

    elif action == "zipfiles":
        try:
            bot.answer_callback_query(
                call.id,
                "📦 Creating ZIP of files... Please wait"
            )
            
            # Non-recursive ZIP (only files in current folder)
            zip_path = f"/tmp/files.zip"
            with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
                for item in os.listdir(path):
                    full_path = os.path.join(path, item)
                    if os.path.isfile(full_path):
                        try:
                            zipf.write(full_path, item)
                        except ValueError:
                            # Skip files with timestamp issues
                            continue
            
            # Check if zip has content
            if os.path.getsize(zip_path) < 100:
                os.remove(zip_path)
                bot.send_message(
                    call.message.chat.id,
                    "❌ No files could be zipped (timestamp issues)"
                )
                return
            
            folder_name = os.path.basename(path) or "root"
            zip_name = f"{folder_name}_files.zip"
            
            with open(zip_path, "rb") as f:
                bot.send_document(
                    call.message.chat.id,
                    f,
                    visible_file_name=zip_name
                )
            
            # Cleanup
            os.remove(zip_path)
            
        except Exception as e:
            bot.send_message(
                call.message.chat.id,
                f"❌ ERROR creating ZIP:\n{str(e)}"
            )

# ==================================================
# RUN BOT
# ==================================================

if __name__ == "__main__":
    while True:
        try:
            print("🤖 BOT RUNNING...")
            bot.infinity_polling(
                timeout=60,
                long_polling_timeout=60,
                skip_pending=True
            )
        except Exception as e:
            print(f"❌ ERROR: {e}")
            time.sleep(5)