import telebot
import requests
import json
import os
import time
import io
import threading
from telebot import types
from telebot.types import InlineKeyboardMarkup, InlineKeyboardButton
import random
import string
from datetime import datetime, timedelta

# ==================== CONFIGURATION ====================
TOKEN = "8794392486:AAF5Vtp0Cmi9UIPEKrtD0gV4GAq-qBh5bk8"
OWNER_ID = 7505070902
API_URL = "https://understand-marks-scotland-connections.trycloudflare.com/setuser"
PANEL_URL = "https://understand-marks-scotland-connections.trycloudflare.com/"
REMOVE_USER_URL = "https://understand-marks-scotland-connections.trycloudflare.com/remove_user/{username}?key=SHADOW-X-MODS"
DB_FILE = "user_sh_data.json"
REQUIRED_REFERRALS = 5
NOTIFICATION_GROUP_ID = -1002750141362

# Force Join Channels File
FORCE_CHATS_FILE = "force_chats.json"

# Backup Config
BACKUP_CHANNEL_FILE = "backup_config.json"
BACKUP_CHANNEL_ID = None  # set via /setbackup or admin panel

DEFAULT_FORCE_CHATS = [
    {
        "type": "channel",
        "username": "@Shadow_Vip_Setup",
        "link": "https://t.me/Shadow_Vip_Setup",
        "name": "𝐒ʜᴀᴅᴏᴡ 𝐕ɪᴘ 𝐒ᴇᴛᴜᴘ",
        "is_private": False,
        "chat_id": None
    }
]

bot = telebot.TeleBot(TOKEN)
user_state = {}
pending_add_channel = {}
pending_remove_user = {}

# ==================== FORCE CHATS DB ====================
def load_force_chats():
    if os.path.exists(FORCE_CHATS_FILE):
        try:
            with open(FORCE_CHATS_FILE, "r") as f:
                return json.load(f)
        except:
            pass
    return DEFAULT_FORCE_CHATS.copy()

def save_force_chats(chats):
    with open(FORCE_CHATS_FILE, "w") as f:
        json.dump(chats, f, indent=2)

FORCE_CHATS = load_force_chats()

# ==================== USER DATABASE ====================
def load_db():
    if not os.path.exists(DB_FILE):
        return {"users": {}}
    try:
        with open(DB_FILE, 'r') as f:
            return json.load(f)
    except:
        return {"users": {}}

def save_db(data):
    with open(DB_FILE, 'w') as f:
        json.dump(data, f, indent=4)

# ==================== BACKUP CHANNEL CONFIG ====================
def load_backup_channel_id():
    global BACKUP_CHANNEL_ID
    if os.path.exists(BACKUP_CHANNEL_FILE):
        try:
            with open(BACKUP_CHANNEL_FILE, "r") as f:
                cfg = json.load(f)
                BACKUP_CHANNEL_ID = cfg.get("backup_channel_id", None)
                return BACKUP_CHANNEL_ID
        except:
            pass
    return None

def save_backup_channel_id(channel_id: int):
    global BACKUP_CHANNEL_ID
    BACKUP_CHANNEL_ID = channel_id
    try:
        with open(BACKUP_CHANNEL_FILE, "w") as f:
            json.dump({"backup_channel_id": channel_id}, f)
    except Exception as e:
        print(f"[BACKUP_CHANNEL] Save error: {e}")

# Load backup channel on startup
load_backup_channel_id()

# ==================== FORCE JOIN SYSTEM ====================
def check_user_joined_all(user_id):
    """𝐑ᴇᴛᴜʀɴꜱ 𝐥ɪꜱᴛ 𝐨ꜰ 𝐜ʜᴀɴɴᴇʟꜱ 𝐮ꜱᴇʀ 𝐡ᴀꜱ 𝐍ᴏᴛ 𝐣ᴏɪɴᴇᴅ."""
    not_joined = []
    for ch in FORCE_CHATS:
        try:
            if ch.get("is_private") and ch.get("chat_id"):
                member = bot.get_chat_member(ch["chat_id"], user_id)
            else:
                uname = ch["username"] if ch["username"].startswith("@") else f"@{ch['username']}"
                member = bot.get_chat_member(uname, user_id)
            if member.status in ["left", "kicked"]:
                not_joined.append(ch)
        except:
            not_joined.append(ch)
    return not_joined

def is_user_joined(user_id):
    return len(check_user_joined_all(user_id)) == 0

def send_join_msg(chat_id, user_id):
    not_joined = check_user_joined_all(user_id)
    if not not_joined:
        return
    text = (
        "🚫 <b>Aᴄᴄᴇꜱꜱ Dᴇɴɪᴇᴅ</b>\n\n"
        "❌ Yᴏᴜ Mᴜꜱᴛ Jᴏɪɴ Tʜᴇꜱᴇ Cʜᴀɴɴᴇʟꜱ Fɪʀꜱᴛ:\n\n"
    )
    markup = InlineKeyboardMarkup()
    for ch in not_joined:
        text += f"• <b>{ch['name']}</b>\n"
        markup.add(InlineKeyboardButton(
            text=f"➕ Jᴏɪɴ {ch['name']}",
            url=ch["link"]
        ))
    markup.add(InlineKeyboardButton(text="✅ Vᴇʀɪꜰʏ", callback_data="verify"))
    bot.send_message(chat_id, text, reply_markup=markup, parse_mode="HTML")

# ==================== BACKUP & RESTORE ====================
def export_db_json():
    """𝐄xᴘᴏʀᴛ 𝐮ꜱᴇʀ_ꜱʜ_ᴅᴀᴛᴀ.ᴊꜱᴏɴ 𝐚ꜱ 𝐬ᴛʀᴜᴄᴛᴜʀᴇᴅ 𝐝ɪᴄᴛ."""
    try:
        db = load_db()
        db_meta = {
            "backup_meta": {
                "version": "1.0",
                "created_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "stats": {"total_users": len(db.get("users", {}))}
            },
            "users_data": db,
            "force_chats": load_force_chats()
        }
        return db_meta
    except Exception as e:
        print(f"[EXPORT] Error: {e}")
        return None

def send_backup_to_channel(channel_id=None):
    """𝐒ᴇɴᴅ 𝐛ᴀᴄᴋᴜᴘ 𝐉ꜱᴏɴ 𝐟ɪʟᴇ 𝐭ᴏ 𝐛ᴀᴄᴋᴜᴘ 𝐜ʜᴀɴɴᴇʟ."""
    target = channel_id or BACKUP_CHANNEL_ID
    if not target:
        return False, "❌ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ 𝐍ᴀʜɪ 𝐇ᴀɪ. 𝐏ᴇʜʟᴇ /𝐒ᴇᴛʙᴀᴄᴋᴜᴘ 𝐔ꜱᴇ 𝐊ᴀʀᴏ."
    try:
        json_data = export_db_json()
        if not json_data:
            return False, "❌ 𝐄xᴘᴏʀᴛ 𝐊ᴀʀɴᴇ 𝐌ᴇɪɴ 𝐄ʀʀᴏʀ 𝐀ᴀʏᴀ."
        json_str = json.dumps(json_data, ensure_ascii=False, indent=2, default=str)
        ts_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        total_users = json_data["backup_meta"]["stats"]["total_users"]
        filename = f"shadow_backup_{int(time.time())}.json"
        caption = (
            f"📦 <b>𝐒ʜᴀᴅᴏᴡ 𝐁ᴏᴛ 𝐁ᴀᴄᴋᴜᴘ</b>\n"
            f"🕐 {ts_str}\n"
            f"👥 𝐔sᴇʀs: <b>{total_users}</b>\n"
            f"📁 <code>{filename}</code>\n"
            f"⚡ 𝐁ʏ : @SHADOW_VIP_OWNER"
        )
        buf = io.BytesIO(json_str.encode("utf-8"))
        buf.name = filename
        sent = bot.send_document(target, buf, caption=caption, parse_mode="HTML")
        try:
            bot.pin_chat_message(target, sent.message_id, disable_notification=True)
        except:
            pass
        # Save restore meta
        try:
            with open("channel_restore_meta.json", "w") as f:
                json.dump({
                    "chat_id": target,
                    "message_id": sent.message_id,
                    "file_id": sent.document.file_id,
                    "saved_at": int(time.time())
                }, f)
        except:
            pass
        print(f"[BACKUP] ✅ {filename} sᴇɴᴅ — {total_users} ᴜsᴇʀs | msg_id:{sent.message_id}")
        return True, f"✅ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐏ᴇ 𝐁ʜᴇᴊ 𝐃ɪʏᴀ!\n👥 𝐔sᴇʀs: {total_users}\n📁 File: {filename}"
    except Exception as e:
        print(f"[BACKUP] ❌ 𝐄ʀʀᴏʀ: {e}")
        return False, f"❌ 𝐁ᴀᴄᴋᴜᴘ 𝐅ᴀɪʟᴇᴅ: {e}"

def restore_from_json(json_data: dict):
    """𝐑ᴇꜱᴛᴏʀᴇ 𝐃ʙ 𝐟ʀᴏᴍ 𝐩ᴀʀꜱᴇᴅ 𝐉ꜱᴏɴ 𝐝ɪᴄᴛ."""
    try:
        users_data = json_data.get("users_data", json_data.get("users", None))
        if not users_data:
            return False, "❌ 𝐉ꜱᴏɴ 𝐌ᴇɪɴ 𝐔ꜱᴇʀꜱ_𝐃ᴀᴛᴀ 𝐍ᴀʜɪ 𝐌ɪʟɪ."
        if "users" not in users_data:
            return False, "❌ 𝐉ꜱᴏɴ 𝐅ᴏʀᴍᴀᴛ 𝐆ᴀʟᴀᴛ 𝐇ᴀɪ."
        save_db(users_data)

        # Restore force chats if present
        fc = json_data.get("force_chats")
        if fc and isinstance(fc, list):
            global FORCE_CHATS
            FORCE_CHATS = fc
            save_force_chats(fc)

        total = len(users_data.get("users", {}))
        return True, f"✅ 𝐑ᴇsᴛᴏʀᴇ 𝐂ᴏᴍᴘʟᴇᴛᴇ!\n👥 𝐔sᴇʀs 𝐑ᴇsᴛᴏʀᴇᴅ: {total}"
    except Exception as e:
        return False, f"❌ 𝐑ᴇsᴛᴏʀᴇ 𝐅ᴀɪʟᴇᴅ: {e}"

# ==================== ADMIN PANEL ====================
def admin_panel_text():
    db = load_db()
    total_users = len(db.get("users", {}))
    total_panels = sum(u.get("panels_created", 0) for u in db["users"].values())
    fc_count = len(FORCE_CHATS)
    backup_ch = f"<code>{BACKUP_CHANNEL_ID}</code>" if BACKUP_CHANNEL_ID else "❌ 𝐍ᴏᴛ 𝐒ᴇᴛ"
    return (
        "🛡️ <b>𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 <b>𝐓ᴏᴛᴀʟ 𝐔sᴇʀs:</b> <code>{total_users}</code>\n"
        f"🚀 <b>𝐓ᴏᴛᴀʟ 𝐏ᴀɴᴇʟs:</b> <code>{total_panels}</code>\n"
        f"📢 <b>𝐅ᴏʀᴄᴇ 𝐂ʜᴀɴɴᴇʟs:</b> <code>{fc_count}</code>\n"
        f"💾 <b>𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ:</b> {backup_ch}\n\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    )

def admin_panel_keyboard():
    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("📢 𝐁ʀᴏᴀᴅᴄᴀꜱᴛ", callback_data="admin_broadcast"),
        InlineKeyboardButton("👥 𝐔ꜱᴇʀꜱ 𝐈ɴꜰᴏ", callback_data="admin_users")
    )
    markup.row(
        InlineKeyboardButton("➕ 𝐀ᴅᴅ 𝐂ʜᴀɴɴᴇʟ", callback_data="admin_add_channel"),
        InlineKeyboardButton("➖ 𝐑ᴇᴍᴏᴠᴇ 𝐂ʜᴀɴɴᴇʟ", callback_data="admin_remove_channel")
    )
    markup.row(
        InlineKeyboardButton("📋 𝐋ɪꜱᴛ 𝐂ʜᴀɴɴᴇʟꜱ", callback_data="admin_list_channels"),
        InlineKeyboardButton("🗑️ 𝐑ᴇᴍᴏᴠᴇ 𝐔ꜱᴇʀ", callback_data="admin_remove_user")
    )
    markup.row(
        InlineKeyboardButton("💾 𝐁ᴀᴄᴋᴜᴘ 𝐍ᴏᴡ", callback_data="admin_backup"),
        InlineKeyboardButton("♻️ 𝐑ᴇꜱᴛᴏʀᴇ", callback_data="admin_restore")
    )
    markup.row(
        InlineKeyboardButton("📡 𝐒ᴇᴛ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜ", callback_data="admin_set_backup_ch")
    )
    return markup

@bot.message_handler(commands=['admin'])
def admin_panel(message):
    if message.from_user.id != OWNER_ID:
        bot.reply_to(message, "⛔ 𝐀ᴄᴄᴇꜱꜱ 𝐃ᴇɴɪᴇᴅ.")
        return
    bot.send_message(
        message.chat.id,
        admin_panel_text(),
        reply_markup=admin_panel_keyboard(),
        parse_mode="HTML"
    )

@bot.callback_query_handler(func=lambda call: call.data.startswith("admin_"))
def handle_admin_callbacks(call):
    if call.from_user.id != OWNER_ID:
        bot.answer_callback_query(call.id, "⛔ 𝐀ᴄᴄᴇꜱꜱ 𝐃ᴇɴɪᴇᴅ!", show_alert=True)
        return

    chat_id = call.message.chat.id
    data = call.data

    # ── Back to admin panel ──
    if data == "admin_back":
        bot.edit_message_text(
            admin_panel_text(), chat_id, call.message.message_id,
            reply_markup=admin_panel_keyboard(), parse_mode="HTML"
        )
        bot.answer_callback_query(call.id)

    # ── Broadcast ──
    elif data == "admin_broadcast":
        bot.edit_message_text(
            "📢 <b>𝐁ʀᴏᴀᴅᴄᴀꜱᴛ</b>\n\n𝐀ʙ 𝐉ᴏ 𝐌ᴇꜱꜱᴀɢᴇ 𝐁ʜᴇᴊᴏɢᴇ 𝐖ᴏ 𝐒ᴀʙ 𝐔ꜱᴇʀꜱ 𝐊ᴏ 𝐉ᴀʏᴇɢᴀ.\n"
            "𝐓ᴇxᴛ 𝐍ʜᴇᴊᴏ 𝐘ᴀ 𝐊ɪꜱɪ 𝐌ᴇꜱꜱᴀɢᴇ 𝐊ᴏ 𝐑ᴇᴘʟʏ 𝐊ᴀʀᴏ /𝐁ʀᴏᴀᴅᴄᴀꜱᴛ 𝐂ᴏᴍᴍᴀɴᴅ 𝐒ᴇ.",
            chat_id, call.message.message_id,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]]),
            parse_mode="HTML"
        )
        bot.answer_callback_query(call.id)

    # ── Users Info ──
    elif data == "admin_users":
        db = load_db()
        users = db.get("users", {})
        total = len(users)
        total_panels = sum(u.get("panels_created", 0) for u in users.values())
        total_refs = sum(u.get("referrals", 0) for u in users.values())
        txt = (
            "👥 <b>𝐔ꜱᴇʀꜱ 𝐒ᴛᴀᴛɪꜱᴛɪᴄꜱ</b>\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            f"👤 <b>𝐓ᴏᴛᴀʟ 𝐔sᴇʀs:</b> <code>{total}</code>\n"
            f"🚀 <b>𝐓ᴏᴛᴀʟ 𝐏ᴀɴᴇʟs:</b> <code>{total_panels}</code>\n"
            f"🔗 <b>𝐓ᴏᴛᴀʟ 𝐑ᴇғᴇʀʀᴀʟs:</b> <code>{total_refs}</code>\n\n"
            "━━━━━━━━━━━━━━━━━━━━━━━━━━"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]])
        bot.edit_message_text(txt, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        bot.answer_callback_query(call.id)

    # ── Add Channel ──
    elif data == "admin_add_channel":
        txt = (
            "➕ <b>𝐂ʜᴀɴɴᴇʟ 𝐀ᴅᴅ 𝐊ᴀʀᴏ</b>\n\n"
            "𝐅ᴏʀᴍᴀᴛ:\n<code>@username | 𝐍ᴀᴍᴇ | https://t.me/x | 𝐜ʜᴀɴɴᴇʟ</code>\n\n"
            "𝐄xᴀᴍᴘʟᴇ:\n<code>@MyShadowCh | 𝐒ʜᴀᴅᴏᴡ 𝐕ɪᴘ | https://t.me/MyShadowCh | 𝐜ʜᴀɴɴᴇʟ</code>\n\n"
            "𝐏ʀɪᴠᴀᴛᴇ 𝐂ʜᴀɴɴᴇʟ 𝐊ᴇ 𝐥ɪʏᴇ:\n<code>𝐍ᴀᴍᴇ | https://t.me/+xxx | -100𝐱xxxxxx | 𝐂ʜᴀɴɴᴇʟ</code>"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]])
        msg = bot.edit_message_text(txt, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        pending_add_channel[chat_id] = {"type": "add_public", "msg_id": call.message.message_id}
        bot.register_next_step_handler(msg, handle_add_channel_input)
        bot.answer_callback_query(call.id)

    # ── Remove Channel ──
    elif data == "admin_remove_channel":
        if not FORCE_CHATS:
            bot.answer_callback_query(call.id, "❌ 𝐊ᴏɪ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ 𝐍ᴀʜɪ 𝐇ᴀɪ!", show_alert=True)
            return
        markup = InlineKeyboardMarkup()
        for i, ch in enumerate(FORCE_CHATS):
            markup.add(InlineKeyboardButton(
                f"🗑️ {ch['name']} ({ch.get('username', 'Private')})",
                callback_data=f"admin_del_ch_{i}"
            ))
        markup.add(InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back"))
        bot.edit_message_text(
            "➖ <b>𝐂ʜᴀɴɴᴇʟ 𝐑ᴇᴍᴏᴠᴇ 𝐊ᴀʀᴏ</b>\n\n𝐒ᴇʟᴇᴄᴛ 𝐂ʜᴀɴɴᴇʟ 𝐓ᴏ 𝐑ᴇᴍᴏᴠᴇ:",
            chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML"
        )
        bot.answer_callback_query(call.id)

    # ── Delete specific channel ──
    elif data.startswith("admin_del_ch_"):
        idx = int(data.split("_")[-1])
        if 0 <= idx < len(FORCE_CHATS):
            removed = FORCE_CHATS.pop(idx)
            save_force_chats(FORCE_CHATS)
            bot.answer_callback_query(call.id, f"✅ {removed['name']} 𝐑ᴇᴍᴏᴠᴇ 𝐇ᴏ 𝐆ᴀʏᴀ!", show_alert=True)
        bot.edit_message_text(
            admin_panel_text(), chat_id, call.message.message_id,
            reply_markup=admin_panel_keyboard(), parse_mode="HTML"
        )

    # ── List Channels ──
    elif data == "admin_list_channels":
        if not FORCE_CHATS:
            txt = "📋 <b>𝐅ᴏʀᴄᴇ 𝐂ʜᴀɴɴᴇʟꜱ</b>\n\n❌ 𝐊ᴏɪ 𝐜ʜᴀɴɴᴇʟ 𝐬ᴇᴛ 𝐧ᴀʜɪ 𝐡ᴀɪ."
        else:
            txt = "📋 <b>𝐅ᴏʀᴄᴇ 𝐂ʜᴀɴɴᴇʟꜱ 𝐋ɪꜱᴛ</b>\n━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
            for i, ch in enumerate(FORCE_CHATS, 1):
                kind = "🔒 𝐏ʀɪᴠᴀᴛᴇ" if ch.get("is_private") else "🔓 𝐏ᴜʙʟɪᴄ"
                txt += (
                    f"<b>{i}. {ch['name']}</b>\n"
                    f"   {kind} | {ch.get('username', ch.get('chat_id', 'N/A'))}\n"
                    f"   🔗 {ch['link']}\n\n"
                )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]])
        bot.edit_message_text(txt, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        bot.answer_callback_query(call.id)

    # ── Remove User (web) ──
    elif data == "admin_remove_user":
        txt = (
            "🗑️ <b>𝐑ᴇᴍᴏᴠᴇ 𝐖ᴇʙ 𝐔ꜱᴇʀ</b>\n\n"
            "𝐉ᴏ 𝐔ꜱᴇʀ 𝐊ᴀ 𝐏ᴀɴᴇʟ 𝐖ᴇʙ 𝐒ᴇ 𝐃ᴇʟᴇᴛᴇ 𝐊ᴀʀɴᴀ 𝐇ᴀɪ 𝐔ꜱᴋᴀ 𝐔ꜱᴇʀɴᴀᴍᴇ 𝐁ʜᴇᴊᴏ.\n\n"
            "⚠️ 𝐘ᴇ 𝐔ꜱᴇʀ 𝐊ᴀ 𝐖ᴇʙ 𝐀ᴄᴄᴏᴜɴᴛ 𝐏ᴇʀᴍᴀɴᴇɴᴛʟʏ 𝐃ᴇʟᴇᴛᴇ 𝐊ᴀʀ 𝐃ᴇɢᴀ!"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]])
        msg = bot.edit_message_text(txt, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        pending_remove_user[chat_id] = True
        bot.register_next_step_handler(msg, process_remove_user)
        bot.answer_callback_query(call.id)

    # ── Backup ──
    elif data == "admin_backup":
        bot.answer_callback_query(call.id, "⏳ 𝐁ᴀᴄᴋᴜᴘ 𝐇ᴏ 𝐑ᴀʜᴀ 𝐇ᴀɪ...")
        if not BACKUP_CHANNEL_ID:
            bot.send_message(chat_id, "❌ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ 𝐍ᴀʜɪ 𝐇ᴀɪ!\n\n'📡 𝐒ᴇᴛ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜ' 𝐁ᴜᴛᴛᴏɴ 𝐔ꜱᴇ 𝐊ᴀʀᴏ 𝐘ᴀ /𝐒ᴇᴛʙᴀᴄᴋᴜᴘ 𝐂ᴏᴍᴍᴀɴᴅ 𝐔ꜱᴇ 𝐊ᴀʀᴏ.")
            return
        success, msg_text = send_backup_to_channel()
        bot.send_message(chat_id, msg_text, parse_mode="HTML")

    # ── Restore ──
    elif data == "admin_restore":
        txt = (
            "♻️ <b>𝐑ᴇꜱᴛᴏʀᴇ</b>\n\n"
            "𝐁ᴀᴄᴋᴜᴘ 𝐉ꜱᴏɴ 𝐅ɪʟᴇ 𝐘ᴀʜᴀɴ 𝐅ᴏʀᴡᴀʀᴅ/𝐒ᴇɴᴅ 𝐊ᴀʀᴏ.\n\n"
            "⚠️ 𝐘ᴇ 𝐂ᴜʀʀᴇɴᴛ 𝐃ᴀᴛᴀ 𝐊ᴏ 𝐎ᴠᴇʀᴡʀɪᴛᴇ 𝐊ᴀʀ 𝐃ᴇɢᴀ!"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]])
        msg = bot.edit_message_text(txt, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        bot.register_next_step_handler(msg, process_restore_file)
        bot.answer_callback_query(call.id)

    # ── Set Backup Channel ──
    elif data == "admin_set_backup_ch":
        txt = (
            "📡 <b>𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ 𝐊ᴀʀᴏ</b>\n\n"
            "𝐂ʜᴀɴɴᴇʟ 𝐈ᴅ 𝐘ᴀ 𝐔ꜱᴇʀɴᴀᴍᴇ 𝐁ʜᴇᴊᴏ:\n"
            "𝐄xᴀᴍᴘʟᴇ: <code>-1001234567890</code> 𝐲ᴀ <code>@MyChan</code>\n\n"
            "⚠️ 𝐁ᴏᴛ 𝐊ᴏ 𝐔ꜱ 𝐂ʜᴀɴɴᴇʟ 𝐊ᴀ 𝐀ᴅᴍɪɴ 𝐁ᴀɴᴀɴᴀ 𝐇ᴏɢᴀ!"
        )
        markup = InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐁ᴀᴄᴋ", callback_data="admin_back")]])
        msg = bot.edit_message_text(txt, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        bot.register_next_step_handler(msg, process_set_backup_channel)
        bot.answer_callback_query(call.id)

# ==================== ADMIN NEXT STEP HANDLERS ====================

def handle_add_channel_input(message):
    if message.from_user.id != OWNER_ID:
        return
    chat_id = message.chat.id
    text = message.text.strip() if message.text else ""
    try:
        parts = [p.strip() for p in text.split("|")]
        if len(parts) == 4:
            # Check if first part starts with @ = public channel
            if parts[0].startswith("@"):
                username, name, link, ctype = parts
                FORCE_CHATS.append({
                    "type": ctype.lower(), "username": username,
                    "link": link, "name": name,
                    "is_private": False, "chat_id": None
                })
                save_force_chats(FORCE_CHATS)
                bot.send_message(
                    chat_id,
                    f"✅ <b>𝐂ʜᴀɴɴᴇʟ 𝐀ᴅᴅᴇᴅ!</b>\n\n"
                    f"📢 <b>{name}</b>\n🔓 𝐏ᴜʙʟɪᴄ | {username}\n🔗 {link}",
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ", callback_data="admin_back")]])
                )
            else:
                # Private channel: Name | link | chat_id | type
                name, link, chat_id_str, ctype = parts
                chat_id_int = int(chat_id_str)
                FORCE_CHATS.append({
                    "type": ctype.lower(), "username": None,
                    "link": link, "name": name,
                    "is_private": True, "chat_id": chat_id_int
                })
                save_force_chats(FORCE_CHATS)
                bot.send_message(
                    chat_id,
                    f"✅ <b>𝐏ʀɪᴠᴀᴛᴇ 𝐂ʜᴀɴɴᴇʟ 𝐀ᴅᴅᴇᴅ!</b>\n\n"
                    f"📢 <b>{name}</b>\n🔒 𝐏ʀɪᴠᴀᴛᴇ | 𝐈ᴅ: <code>{chat_id_int}</code>\n🔗 {link}\n\n"
                    f"⚠️ 𝐁ᴏᴛ 𝐊ᴏ 𝐂ʜᴀɴɴᴇʟ 𝐊ᴀ 𝐀ᴅᴍɪɴ 𝐁ᴀɴᴀɴᴀ 𝐇ᴏɢᴀ!",
                    parse_mode="HTML",
                    reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ", callback_data="admin_back")]])
                )
        else:
            raise ValueError("𝐖ʀᴏɴɢ 𝐅ᴏʀᴍᴀᴛ")
    except Exception as e:
        bot.send_message(
            chat_id,
            f"❌ Error: {e}\n\nFormat:\n"
            "<code>@username | 𝐍ᴀᴍᴇ | https://t.me/x | 𝐜ʜᴀɴɴᴇʟ</code>\n\n"
            "𝐘ᴀ 𝐏ʀɪᴠᴀᴛᴇ 𝐊ᴇ 𝐋ɪʏᴇ:\n"
            "<code>𝐍ᴀᴍᴇ | https://t.me/+xxx | -100𝐱xxxxxx | 𝐂ʜᴀɴɴᴇʟ</code>",
            parse_mode="HTML"
        )

def process_remove_user(message):
    if message.from_user.id != OWNER_ID:
        return
    chat_id = message.chat.id
    if chat_id not in pending_remove_user:
        return
    del pending_remove_user[chat_id]

    username = message.text.strip().lstrip("@") if message.text else ""
    if not username:
        bot.send_message(chat_id, "❌ 𝐈ɴᴠᴀʟɪᴅ 𝐔ꜱᴇʀɴᴀᴍᴇ!")
        return

    wait_msg = bot.send_message(chat_id, f"⏳ <b>{username}</b> 𝐊ᴏ 𝐑ᴇᴍᴏᴠᴇ 𝐊ᴀʀ 𝐑ᴀʜᴀ 𝐇ᴜ...", parse_mode="HTML")
    try:
        url = REMOVE_USER_URL.format(username=username)
        response = requests.get(url, timeout=15)
        if response.status_code == 200:
            try:
                res_data = response.json()
                status = res_data.get("status", "unknown")
                msg_resp = res_data.get("message", res_data.get("msg", "Done"))
                if status in ["success", "ok", True, "true"] or response.status_code == 200:
                    result_text = (
                        f"✅ <b>𝐔sᴇʀ 𝐑ᴇᴍᴏᴠᴇᴅ!</b>\n\n"
                        f"👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>\n"
                        f"📡 𝐑ᴇsᴘᴏɴsᴇ: {msg_resp}\n"
                        f"🌐 𝐒ᴛᴀᴛᴜs: {response.status_code}"
                    )
                else:
                    result_text = (
                        f"⚠️ <b>𝐑ᴇsᴘᴏɴsᴇ 𝐌ɪʟᴀ:</b>\n\n"
                        f"👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>\n"
                        f"📡 𝐑ᴇsᴘᴏɴsᴇ: {msg_resp}\n"
                        f"🌐 𝐒ᴛᴀᴛᴜs: {status}"
                    )
            except:
                result_text = (
                    f"✅ <b>𝐑ᴇǫᴜᴇsᴛ 𝐒ᴇɴᴅ 𝐇ᴏ 𝐆ᴀʏᴀ!</b>\n\n"
                    f"👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>\n"
                    f"🌐 𝐇ᴛᴛᴘ 𝐒ᴛᴀᴛᴜs: {response.status_code}\n"
                    f"📄 𝐑ᴇsᴘᴏɴsᴇ: {response.text[:200]}"
                )
        else:
            result_text = (
                f"❌ <b>𝐑ᴇᴍᴏᴠᴇ 𝐅ᴀɪʟᴇᴅ!</b>\n\n"
                f"👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>\n"
                f"🌐 𝐇ᴛᴛᴘ 𝐒ᴛᴀᴛᴜs: {response.status_code}\n"
                f"📄 𝐑ᴇsᴘᴏɴsᴇ: {response.text[:200]}"
            )
    except requests.exceptions.ConnectionError:
        result_text = f"❌ <b>𝐂ᴏɴɴᴇᴄᴛɪᴏɴ 𝐄ʀʀᴏʀ!</b>\n𝐒ᴇʀᴠᴇʀ 𝐒ᴇ 𝐂ᴏɴɴᴇᴄᴛ 𝐍ᴀʜɪ 𝐇ᴏ 𝐒ᴀᴋᴀ.\n👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>"
    except requests.exceptions.Timeout:
        result_text = f"❌ <b>Timeout!</b>\n𝐒ᴇʀᴠᴇʀ 𝐍ᴇ 𝐑ᴇsᴘᴏɴsᴇ 𝐍ᴀʜɪ 𝐊ɪʏᴀ.\n👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>"
    except Exception as e:
        result_text = f"❌ <b>Error:</b> {str(e)}\n👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>"

    try:
        bot.delete_message(chat_id, wait_msg.message_id)
    except:
        pass
    bot.send_message(chat_id, result_text, parse_mode="HTML",
                     reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ", callback_data="admin_back")]]))

def process_restore_file(message):
    if message.from_user.id != OWNER_ID:
        return
    chat_id = message.chat.id

    if not message.document:
        bot.send_message(chat_id, "❌ 𝐊ᴏɪ 𝐅ɪʟᴇ 𝐍ᴀʜɪ 𝐌ɪʟɪ. 𝐉ꜱᴏɴ 𝐅ɪʟᴇ 𝐁ʜᴇᴊᴏ.")
        return

    wait_msg = bot.send_message(chat_id, "⏳ 𝐅ɪʟᴇ 𝐏ʀᴏᴄᴇꜱꜱ 𝐇ᴏ 𝐑ᴀʜɪ 𝐇ᴀɪ...")
    try:
        file_info = bot.get_file(message.document.file_id)
        downloaded = bot.download_file(file_info.file_path)
        json_data = json.loads(downloaded.decode("utf-8"))
        success, result_text = restore_from_json(json_data)
    except json.JSONDecodeError:
        success = False
        result_text = "❌ 𝐈ɴᴠᴀʟɪᴅ 𝐉ꜱᴏɴ 𝐅ɪʟᴇ. 𝐅ɪʟᴇ 𝐂ᴏʀʀᴜᴘᴛ 𝐡ᴀɪ 𝐘ᴀ 𝐉ꜱᴏɴ 𝐅ᴏʀᴍᴀᴛ 𝐆ᴀʟᴀᴛ 𝐇ᴀɪ."
    except Exception as e:
        success = False
        result_text = f"❌ 𝐑ᴇsᴛᴏʀᴇ 𝐅ᴀɪʟᴇᴅ: {e}"

    try:
        bot.delete_message(chat_id, wait_msg.message_id)
    except:
        pass
    bot.send_message(chat_id, result_text, parse_mode="HTML",
                     reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ", callback_data="admin_back")]]))

def process_set_backup_channel(message):
    if message.from_user.id != OWNER_ID:
        return
    chat_id = message.chat.id
    text = message.text.strip() if message.text else ""

    try:
        if text.startswith("@"):
            # Username diya
            ch_info = bot.get_chat(text)
            channel_id = ch_info.id
        else:
            channel_id = int(text)

        save_backup_channel_id(channel_id)
        bot.send_message(
            chat_id,
            f"✅ <b>𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ!</b>\n\n"
            f"📡 𝐂ʜᴀɴɴᴇʟ 𝐈ᴅ: <code>{channel_id}</code>\n\n"
            f"𝐀ʙ /backup 𝐘ᴀ 𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ 𝐒ᴇ 𝐁ᴀᴄᴋᴜᴘ 𝐋ᴇ 𝐒ᴀᴋᴛᴇ 𝐇ᴏ.",
            parse_mode="HTML",
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 𝐀ᴅᴍɪɴ 𝐏ᴀɴᴇʟ", callback_data="admin_back")]])
        )
    except Exception as e:
        bot.send_message(chat_id, f"❌ 𝐄ʀʀᴏʀ: {e}\n\n𝐂ʜᴀɴɴᴇʟ 𝐈ᴅ 𝐅ᴏʀᴍᴀᴛ: <code>-1001234567890</code>", parse_mode="HTML")

# ==================== COMMANDS ====================

@bot.message_handler(commands=['setbackup'])
def cmd_setbackup(message):
    if message.from_user.id != OWNER_ID:
        return
    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(message, "❌ 𝐔ꜱᴀɢᴇ: /𝐒ᴇᴛʙᴀᴄᴋᴜᴘ -1001234567890")
        return
    try:
        channel_id = int(parts[1])
        save_backup_channel_id(channel_id)
        bot.reply_to(message, f"✅ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ: <code>{channel_id}</code>", parse_mode="HTML")
    except:
        bot.reply_to(message, "❌ 𝐈ɴᴠᴀʟɪᴅ 𝐂ʜᴀɴɴᴇʟ 𝐈ᴅ.")

@bot.message_handler(commands=['backup'])
def cmd_backup(message):
    if message.from_user.id != OWNER_ID:
        bot.reply_to(message, "⛔ 𝐀ᴄᴄᴇꜱꜱ 𝐃ᴇɴɪᴇᴅ.")
        return
    if not BACKUP_CHANNEL_ID:
        bot.reply_to(message, "❌ 𝐁ᴀᴄᴋᴜᴘ 𝐂ʜᴀɴɴᴇʟ 𝐒ᴇᴛ 𝐍ᴀʜɪ 𝐇ᴀɪ!\n𝐏ᴇʜʟᴇ /𝐒ᴇᴛʙᴀᴄᴋᴜᴘ <channel_id> 𝐔ꜱᴇ 𝐊ᴀʀᴏ.")
        return
    wait = bot.reply_to(message, "⏳ 𝐁ᴀᴄᴋᴜᴘ 𝐇ᴏ 𝐑ᴀʜᴀ 𝐇ᴀɪ...")
    success, result_text = send_backup_to_channel()
    try:
        bot.delete_message(message.chat.id, wait.message_id)
    except:
        pass
    bot.send_message(message.chat.id, result_text, parse_mode="HTML")

@bot.message_handler(commands=['restore'])
def cmd_restore(message):
    if message.from_user.id != OWNER_ID:
        bot.reply_to(message, "⛔ 𝐀ᴄᴄᴇꜱꜱ 𝐃ᴇɴɪᴇᴅ.")
        return
    if not message.reply_to_message or not message.reply_to_message.document:
        bot.reply_to(message, "❌ 𝐊ɪꜱɪ 𝐉ꜱᴏɴ 𝐅ɪʟᴇ 𝐊ᴏ 𝐑ᴇᴘʟʏ 𝐊ᴀʀᴏ /𝐑ᴇꜱᴛᴏʀᴇ 𝐊ᴇ 𝐒ᴀᴀᴛʜ.")
        return
    wait = bot.reply_to(message, "⏳ 𝐑ᴇꜱᴛᴏʀᴇ 𝐇ᴏ 𝐑ᴀʜᴀ 𝐇ᴀɪ...")
    try:
        file_info = bot.get_file(message.reply_to_message.document.file_id)
        downloaded = bot.download_file(file_info.file_path)
        json_data = json.loads(downloaded.decode("utf-8"))
        success, result_text = restore_from_json(json_data)
    except json.JSONDecodeError:
        result_text = "❌ 𝐈ɴᴠᴀʟɪᴅ 𝐉ꜱᴏɴ 𝐅ɪʟᴇ."
    except Exception as e:
        result_text = f"❌ Error: {e}"
    try:
        bot.delete_message(message.chat.id, wait.message_id)
    except:
        pass
    bot.send_message(message.chat.id, result_text, parse_mode="HTML")

@bot.message_handler(commands=['removeuser'])
def cmd_remove_user(message):
    if message.from_user.id != OWNER_ID:
        return
    parts = message.text.split()
    if len(parts) < 2:
        bot.reply_to(message, "❌ 𝐔ꜱᴀɢᴇ: /𝐑ᴇᴍᴏᴠᴇᴜꜱᴇʀ 𝐔ꜱᴇʀɴᴀᴍᴇ")
        return
    username = parts[1].lstrip("@")
    wait = bot.reply_to(message, f"⏳ <b>{username}</b> 𝐊ᴏ 𝐑ᴇᴍᴏᴠᴇ 𝐊ᴀʀ 𝐑ʜᴀ 𝐇ᴜ...", parse_mode="HTML")
    try:
        url = REMOVE_USER_URL.format(username=username)
        response = requests.get(url, timeout=15)
        try:
            res_data = response.json()
            msg_resp = res_data.get("message", res_data.get("msg", "Done"))
        except:
            msg_resp = response.text[:200]
        result_text = (
            f"✅ <b>𝐑ᴇǫᴜᴇsᴛ 𝐒ᴇɴᴛ!</b>\n\n"
            f"👤 𝐔sᴇʀɴᴀᴍᴇ: <code>{username}</code>\n"
            f"🌐 𝐇ᴛᴛᴘ: {response.status_code}\n"
            f"📡 𝐑ᴇsᴘᴏɴsᴇ: {msg_resp}"
        )
    except Exception as e:
        result_text = f"❌ Error: {e}"
    try:
        bot.delete_message(message.chat.id, wait.message_id)
    except:
        pass
    bot.send_message(message.chat.id, result_text, parse_mode="HTML")

@bot.message_handler(commands=['broadcast'])
def broadcast(message):
    if message.from_user.id != OWNER_ID:
        bot.reply_to(message, "⛔ 𝐀ᴄᴄᴇꜱꜱ 𝐃ᴇɴɪᴇᴅ.")
        return
    if not message.reply_to_message and len(message.text.split()) == 1:
        bot.send_message(
            message.chat.id,
            "❌ <b>𝐔ꜱᴀɢᴇ:</b>\n1. /𝐁ʀᴏᴀᴅᴄᴀꜱᴛ 𝐘ᴏᴜʀ 𝐌ᴇꜱꜱᴀɢᴇ\n2. 𝐑ᴇᴘʟʏ 𝐊ᴀʀᴏ 𝐊ɪꜱɪ 𝐌ᴇꜱꜱᴀɢᴇ 𝐩ᴇ /𝐁ʀᴏᴀᴅᴄᴀꜱᴛ",
            parse_mode="HTML"
        )
        return
    db = load_db()
    users_dict = db.get("users", {})
    sent_count = fail_count = 0
    status_msg = bot.send_message(message.chat.id, "⏳ <b>𝐁ʀᴏᴀᴅᴄᴀꜱᴛɪɴɢ...</b>", parse_mode="HTML")
    for user_id in users_dict:
        try:
            if message.reply_to_message:
                bot.copy_message(user_id, message.chat.id, message.reply_to_message.message_id)
            else:
                msg_to_send = message.text.split(None, 1)[1]
                bot.send_message(user_id, msg_to_send, parse_mode="HTML")
            sent_count += 1
            time.sleep(0.1)
        except:
            fail_count += 1
    report = (
        "📢 <b>𝐁ʀᴏᴀᴅᴄᴀꜱᴛ 𝐂ᴏᴍᴘʟᴇᴛᴇ!</b>\n\n"
        f"✅ 𝐒ᴇɴᴅ: <code>{sent_count}</code>\n"
        f"❌ 𝐅ᴀɪʟᴇᴅ: <code>{fail_count}</code>"
    )
    bot.edit_message_text(report, message.chat.id, status_msg.message_id, parse_mode="HTML")

@bot.message_handler(commands=['status'])
def admin_status(message):
    if message.from_user.id != OWNER_ID:
        return
    db = load_db()
    users = db.get("users", {})
    total_users = len(users)
    total_panels = sum(u.get("panels_created", 0) for u in users.values())
    total_refs = sum(u.get("referrals", 0) for u in users.values())
    status_msg = (
        "📊 <b>𝐁ᴏᴛ 𝐒ᴛᴀᴛɪꜱᴛɪᴄꜱ</b>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        f"👥 <b>𝐓ᴏᴛᴀʟ 𝐔sᴇʀs:</b> <code>{total_users}</code>\n"
        f"🔗 <b>𝐓ᴏᴛᴀʟ 𝐑ᴇғᴇʀʀᴀʟs:</b> <code>{total_refs}</code>\n"
        f"🚀 <b>𝐓ᴏᴛᴀʟ 𝐏ᴀɴᴇʟs:</b> <code>{total_panels}</code>\n\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━"
    )
    bot.send_message(message.chat.id, status_msg, parse_mode="HTML")

@bot.message_handler(commands=['addref'])
def add_referral(message):
    if message.from_user.id != OWNER_ID:
        return
    try:
        args = message.text.split()
        if len(args) < 3:
            bot.reply_to(message, "❌ 𝐔ꜱᴀɢᴇ: /𝐀ᴅᴅʀᴇꜰ {user_id} {count}")
            return
        target_id = args[1]
        count = int(args[2])
        db = load_db()
        if target_id in db["users"]:
            db["users"][target_id]["referrals"] += count
            save_db(db)
            bot.send_message(message.chat.id, f"✅ 𝐀ᴅᴅᴇᴅ <code>{count}</code> 𝐑ᴇғᴇʀʀᴀʟs 𝐓ᴏ <code>{target_id}</code>", parse_mode="HTML")
            try:
                bot.send_message(int(target_id), f"🎁 <b>𝐀ᴅᴍɪɴ 𝐍ᴇ 𝐀ᴀᴘᴋᴏ {count} 𝐑ᴇғᴇʀʀᴀʟs 𝐏ᴏɪɴᴛs 𝐃ɪʏᴇ!</b>", parse_mode="HTML")
            except: pass
        else:
            bot.reply_to(message, "❌ 𝐔ꜱᴇʀ 𝐍ᴏᴛ 𝐅ᴏᴜɴᴅ!")
    except ValueError:
        bot.reply_to(message, "❌ 𝐂ᴏᴜɴᴛ 𝐌ᴜꜱᴛ 𝐁ᴇ 𝐀 𝐍ᴜᴍʙᴇʀ!")
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {e}")

@bot.message_handler(commands=['removeref'])
def remove_referral(message):
    if message.from_user.id != OWNER_ID:
        return
    try:
        args = message.text.split()
        if len(args) < 3:
            bot.reply_to(message, "❌ 𝐔ꜱᴀɢᴇ: /𝐑ᴇᴍᴏᴠᴇʀᴇꜰ {user_id} {count}")
            return
        target_id = args[1]
        count = int(args[2])
        db = load_db()
        if target_id in db["users"]:
            current = db["users"][target_id].get("referrals", 0)
            db["users"][target_id]["referrals"] = max(0, current - count)
            save_db(db)
            bot.send_message(message.chat.id, f"✅ 𝐑ᴇᴍᴏᴠᴇᴅ 𝐍ᴇᴡ 𝐁ᴀʟᴀɴᴄᴇ: <code>{db['users'][target_id]['referrals']}</code>", parse_mode="HTML")
        else:
            bot.reply_to(message, "❌ 𝐔ꜱᴇʀ 𝐧ᴏᴛ 𝐟ᴏᴜɴᴅ!")
    except ValueError:
        bot.reply_to(message, "❌ 𝐂ᴏᴜɴᴛ 𝐌ᴜꜱᴛ 𝐁ᴇ 𝐀 𝐍ᴜᴍʙᴇʀ!")

# ==================== MAIN DASHBOARD ====================
def show_main_menu(chat_id, user_id, first_name):
    db = load_db()
    user_data = db["users"].get(str(chat_id), {"referrals": 0, "panels_created": 0})
    markup = types.ReplyKeyboardMarkup(row_width=2, resize_keyboard=True)
    markup.add(
        '🚀 Cʀᴇᴀᴛᴇ Pᴀɴᴇʟ', '📁 Mʏ Pᴀɴᴇʟꜱ',
        '🔗 Rᴇꜰᴇʀ & Eᴀʀɴ', '👤 Mʏ Pʀᴏꜰɪʟᴇ',
        '☎️ Sᴜᴩᴩᴏʀᴛ'
    )
    caption = (
        f"👋 <b>Hᴇʟʟᴏ, {first_name}!</b>\n\n"
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃      📊 <b>Uꜱᴇʀ Dᴀꜱʜʙᴏᴀʀᴅ</b>    ┃\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━━┛\n"
        f"👤 <b>Nᴀᴍᴇ:</b> <code>{first_name}</code>\n"
        f"🆔 <b>Uꜱᴇʀ ɪᴅ:</b> <code>{user_id}</code>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
        f"👥 <b>Rᴇꜰᴇʀʀᴀʟꜱ:</b> <code>{user_data['referrals']}</code>\n"
        f"🚀 <b>Pᴀɴᴇʟꜱ Cʀᴇᴀᴛᴇᴅ:</b> <code>{user_data['panels_created']}</code>\n"
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
        "📢 <b>𝐒ᴛᴀᴛᴜꜱ:</b> <code>𝐀ᴄᴛɪᴠᴇ ✅</code>"
    )
    bot.send_message(chat_id, caption, reply_markup=markup, parse_mode="HTML")

# ==================== START HANDLER ====================
@bot.message_handler(commands=['start'])
def start(message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id
    first_name = message.from_user.first_name
    text = message.text
    db = load_db()

    if not is_user_joined(user_id):
        send_join_msg(chat_id, user_id)
        return

    if chat_id not in db["users"]:
        ref_by = None
        if "ref_" in text:
            try:
                ref_by = text.split("ref_")[1]
            except:
                ref_by = None

        db["users"][chat_id] = {
            "referrals": 0,
            "referred_by": ref_by,
            "panels_created": 0,
            "my_panels": []
        }

        if ref_by and ref_by in db["users"] and ref_by != chat_id:
            db["users"][ref_by]["referrals"] += 1
            try:
                bot.send_message(
                    int(ref_by),
                    "🎉 <b>Nᴇᴡ Rᴇꜰᴇʀʀᴀʟ!</b>\n\n"
                    f"<code>{user_id}</code> 𝐉ᴏɪɴᴇᴅ 𝐔sɪɴɢ 𝐘ᴏᴜʀ 𝐋ɪɴᴋ!\n"
                    "⭐ 𝐘ᴏᴜ 𝐆ᴏᴛ <b>+1 𝐑ᴇꜰᴇʀʀᴀʟ 𝐏ᴏɪɴᴛ</b>.",
                    parse_mode="HTML"
                )
            except: pass

        save_db(db)
        bot.send_message(chat_id, "✅ <b>Wᴇʟᴄᴏᴍᴇ! Rᴇɢɪꜱᴛᴇʀᴇᴅ Sᴜᴄᴄᴇꜱꜱꜰᴜʟʟʏ.</b>", parse_mode="HTML")

    elif "ref_" in text:
        bot.send_message(chat_id, "⚠️ <b>𝐀ᴀᴘ 𝐀ʟʀᴇᴀᴅʏ 𝐑ᴇɢɪꜱᴛᴇʀᴇᴅ 𝐇ᴀɪɴ!</b>", parse_mode="HTML")

    show_main_menu(chat_id, user_id, first_name)

# ==================== CREATE PANEL ====================
@bot.message_handler(func=lambda message: message.text == '🚀 Cʀᴇᴀᴛᴇ Pᴀɴᴇʟ')
def check_ref_and_start(message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id

    if not is_user_joined(user_id):
        send_join_msg(chat_id, user_id)
        return

    is_owner = (user_id == OWNER_ID)
    db = load_db()

    if chat_id not in db["users"]:
        bot.send_message(chat_id, "❌ 𝐑ᴇɢɪꜱᴛʀᴀᴛɪᴏɴ 𝐍ᴏᴛ 𝐅ᴏᴜɴᴅ! 𝐏ʟᴇᴀꜱᴇ 𝐓ʏᴘᴇ /𝐒ᴛᴀʀᴛ", parse_mode="HTML")
        return

    user_data = db["users"].get(chat_id, {"referrals": 0})
    refs = user_data.get("referrals", 0)

    if not is_owner and refs < REQUIRED_REFERRALS:
        bot.send_message(
            chat_id,
            f"❌ <b>𝐍ᴏᴛ 𝐄ɴᴏᴜɢʜ 𝐑ᴇғғᴇʀᴀʟs!</b>\n\n"
            f"𝐘ᴏᴜ 𝐍ᴇᴇᴅ <code>{REQUIRED_REFERRALS - refs}</code> 𝐌ᴏʀᴇ 𝐑ᴇғғᴇʀᴀʟs.",
            parse_mode="HTML"
        )
        return

    markup = InlineKeyboardMarkup()
    markup.row(
        InlineKeyboardButton("🐍 𝐏ʏᴛʜᴏɴ", callback_data="set_lang_python"),
        InlineKeyboardButton("🟨 𝐍ᴏᴅᴇ.ᴊꜱ", callback_data="set_lang_js")
    )
    msg_text = "👑 <b>𝐖ᴇʟᴄᴏᴍᴇ 𝐀ᴅᴍɪɴ!</b>\n\n" if is_owner else "✅ <b>𝐑ᴇꜰᴇʀʀᴀʟꜱ 𝐕ᴇʀɪꜰɪᴇᴅ!</b>\n\n"
    msg_text += "🚀 <b>𝐒ᴇʟᴇᴄᴛ 𝐏ᴀɴᴇʟ 𝐓ʏᴘᴇ:</b>"
    bot.send_message(chat_id, msg_text, reply_markup=markup, parse_mode="HTML")

@bot.callback_query_handler(func=lambda call: call.data.startswith('set_lang_'))
def set_language(call):
    chat_id = call.message.chat.id
    lang = "Python" if "python" in call.data else "Node.js"
    user_state[chat_id] = {'language': lang}
    bot.delete_message(chat_id, call.message.message_id)
    bot.send_message(chat_id, f"✅ 𝐒ᴇʟᴇᴄᴛᴇᴅ: <b>{lang}</b>\n\n<b>𝐍ᴏᴡ 𝐄ɴᴛᴇʀ 𝐘ᴏᴜʀ 𝐏ᴀɴᴇʟ 𝐔sᴇʀɴᴀᴍᴇ:</b>", parse_mode="HTML")
    bot.register_next_step_handler(call.message, get_username)

def get_username(message):
    username = message.text.strip()
    chat_id = message.chat.id
    db = load_db()

    exists = False
    for u in db["users"].values():
        if any(p['username'].lower() == username.lower() for p in u.get("my_panels", [])):
            exists = True
            break

    if exists:
        bot.send_message(chat_id, "❌ <b>𝐔ꜱᴇʀɴᴀᴍᴇ 𝐀ʟʀᴇᴀᴅʏ 𝐄xɪꜱᴛꜱ!</b> 𝐒ᴇɴᴅ 𝐀 𝐃ɪꜰꜰᴇʀᴇɴᴛ 𝐨ɴᴇ:", parse_mode="HTML")
        bot.register_next_step_handler(message, get_username)
        return

    if chat_id not in user_state:
        user_state[chat_id] = {}
    user_state[chat_id]['username'] = username
    bot.send_message(chat_id, "✅ 𝐍ᴏᴡ 𝐄ɴᴛᴇʀ 𝐘ᴏᴜʀ <b>𝐏ᴀꜱꜱᴡᴏʀᴅ</b> (𝐌ɪɴ 4 𝐂ʜᴀʀꜱ):", parse_mode="HTML")
    bot.register_next_step_handler(message, finalize_creation)

def finalize_creation(message):
    password = message.text.strip()
    chat_id = str(message.chat.id)
    user_id = message.from_user.id

    state = user_state.get(int(chat_id)) or user_state.get(message.chat.id)
    if not state:
        bot.send_message(chat_id, "❌ 𝐒ᴇꜱꜱɪᴏɴ 𝐄xᴘɪʀᴇᴅ. 𝐏ʟᴇᴀꜱᴇ 𝐒ᴛᴀʀᴛ 𝐀ɢᴀɪɴ.")
        return

    username = state.get('username')
    language = state.get('language', 'Python')
    temp_msg = bot.send_message(chat_id, "⏳ 𝐂ʀᴇᴀᴛɪɴɢ... 𝐏ʟᴇᴀꜱᴇ 𝐖ᴀɪᴛ.")

    try:
        params = {'u': username, 'p': password, 'disk': 1024, 'memory': '512MB', 'days': '30d'}
        response = requests.get(API_URL, params=params)
        res_data = response.json()

        if res_data.get('status') == 'success':
            ist_now = datetime.utcnow() + timedelta(hours=5, minutes=30)
            current_full_time = ist_now.strftime("%Y-%m-%d %I:%M %p")
            date_only = ist_now.strftime("%Y-%m-%d")

            db = load_db()
            random_id = generate_server_id(6)

            new_panel = {
                "username": username,
                "password": password,
                "server_id": random_id,
                "created_at": date_only,
                "language": language,
                "ram": "512 𝐌ʙ",
                "disk": "1 𝐆ʙ",
                "cpu": "30 %"
            }

            if "my_panels" not in db["users"][chat_id]:
                db["users"][chat_id]["my_panels"] = []

            db["users"][chat_id]["my_panels"].append(new_panel)

            if int(user_id) != OWNER_ID:
                db["users"][chat_id]["referrals"] -= REQUIRED_REFERRALS

            db["users"][chat_id]["panels_created"] += 1
            save_db(db)

            lang_emoji = "🐍" if "Python" in language else "🟨"

            user_mention = f"@{message.from_user.username}" if message.from_user.username else f"<code>{user_id}</code>"
            group_msg = (
                "🎉 <b>𝐍ᴇᴡ 𝐏ᴀɴᴇʟ 𝐂ʀᴇᴀᴛᴇᴅ!</b>\n\n"
                f"👤 <b>𝐔sᴇʀ:</b> {user_mention}\n"
                f"📅 <b>𝐃ᴀᴛᴇ:</b> {current_full_time} (IST)\n"
                f"🆔 <b>𝐒ᴇʀᴠᴇʀ 𝐈ᴅ:</b> <code>{random_id}</code>\n"
                f"🖥️ <b>𝐓ʏᴘᴇ:</b> {lang_emoji} {language}\n"
                f"📛 <b>𝐔sᴇʀɴᴀᴍᴇ:</b> <code>{username}</code>\n"
                f"💾 𝐑ᴀᴍ: 512 MB | 💿 𝐃ɪsᴄ: 1 GB | ⚡ 𝐂ᴘᴜ: 30%"
            )
            group_markup = InlineKeyboardMarkup()
            group_markup.add(InlineKeyboardButton(
                text="➕ 𝐂ʀᴇᴀᴛᴇ 𝐒ᴇʀᴠᴇʀ", url=f"https://t.me/{bot.get_me().username}"
            ))
            try:
                bot.send_message(NOTIFICATION_GROUP_ID, group_msg, reply_markup=group_markup, parse_mode="HTML")
            except: pass

            bot.delete_message(chat_id, temp_msg.message_id)

            success_msg = (
                "╔══════════════════╗\n"
                "  ✅ <b>𝐏ᴀɴᴇʟ 𝐂ʀᴇᴀᴛᴇᴅ!</b>\n"
                "╚══════════════════╝\n\n"
                f"🌐 <b>𝐏ᴀɴᴇʟ 𝐔ʀʟ:</b> {PANEL_URL}\n"
                f"👤 <b>𝐔sᴇʀɴᴀᴍᴇ:</b> <code>{username}</code>\n"
                f"🔑 <b>𝐏ᴀssᴡᴏʀᴅ:</b> <code>{password}</code>\n"
                f"🆔 <b>𝐒ᴇʀᴠᴇʀ ɪᴅ:</b> <code>{random_id}</code>\n"
                f"🖥️ <b>𝐓ʏᴘᴇ:</b> {lang_emoji} {language}\n"
                "💾 𝐑ᴀᴍ: 512 𝐌ʙ | 💿 𝐃ɪꜱᴋ: 1 𝐆ʙ ⚡ 𝐂ᴘᴜ: 30%\n\n"
                "🔐 𝐋ᴏɢɪɴ 𝐖ɪᴛʜ 𝐀ʙᴏᴠᴇ 𝐃ᴇᴛᴀɪʟꜱ!"
            )
            markup = InlineKeyboardMarkup()
            markup.add(
                InlineKeyboardButton("🌐 𝐎ᴘᴇɴ 𝐏ᴀɴᴇʟ", url=PANEL_URL),
                InlineKeyboardButton("◀️ 𝐁ᴀᴄᴋ 𝐓ᴏ 𝐌ᴇɴᴜ", callback_data="back_to_menu")
            )
            bot.send_message(chat_id, success_msg, reply_markup=markup, parse_mode="HTML")

            key = int(chat_id) if int(chat_id) in user_state else message.chat.id
            if key in user_state:
                del user_state[key]

        else:
            bot.delete_message(chat_id, temp_msg.message_id)
            bot.send_message(chat_id, f"❌ Error: {res_data.get('msg')}")

    except Exception as e:
        print(f"Error: {e}")
        try:
            bot.delete_message(chat_id, temp_msg.message_id)
        except: pass
        bot.send_message(chat_id, "❌ 𝐒ᴇʀᴠᴇʀ 𝐄ʀʀᴏʀ. 𝐏ʟᴇᴀꜱᴇ 𝐓ʀʏ 𝐀ɢᴀɪɴ 𝐋ᴀᴛᴇʀ.")

# ==================== MY PANELS ====================
@bot.message_handler(func=lambda message: message.text == '📁 Mʏ Pᴀɴᴇʟꜱ')
def my_panels_menu(message):
    chat_id = str(message.chat.id)
    user_id = message.from_user.id

    if not is_user_joined(user_id):
        send_join_msg(chat_id, user_id)
        return

    db = load_db()
    if chat_id not in db["users"]:
        bot.send_message(chat_id, "❌ 𝐑ᴇɢɪꜱᴛʀᴀᴛɪᴏɴ 𝐍ᴏᴛ 𝐅ᴏᴜɴᴅ! 𝐓ʏᴘᴇ /start", parse_mode="HTML")
        return

    panels = db["users"].get(chat_id, {}).get("my_panels", [])
    if not panels:
        bot.send_message(chat_id, "❌ <b>𝐍ᴏ 𝐏ᴀɴᴇʟꜱ 𝐅ᴏᴜɴᴅ!</b>\n𝐘ᴏᴜ 𝐇ᴀᴠᴇɴ'ᴛ 𝐂ʀᴇᴀᴛᴇᴅ 𝐀ɴʏ 𝐏ᴀɴᴇʟꜱ 𝐘ᴇᴛ.", parse_mode="HTML")
        return

    markup = InlineKeyboardMarkup()
    for i, panel in enumerate(panels):
        lang = panel.get('language', 'Python')
        emoji = "🐍" if "Python" in lang else "🟨"
        markup.add(InlineKeyboardButton(
            text=f"🔵 {emoji} {panel['username']}",
            callback_data=f"view_panel_{i}"
        ))
    markup.add(InlineKeyboardButton("🌐 𝐎ᴘᴇɴ 𝐏ᴀɴᴇʟ 𝐃ᴀꜱʜʙᴏᴀʀᴅ", url=PANEL_URL))
    bot.send_message(chat_id, "📁 <b>𝐘ᴏᴜʀ 𝐂ʀᴇᴀᴛᴇᴅ 𝐏ᴀɴᴇʟꜱ:</b>\n\n𝐒ᴇʟᴇᴄᴛ 𝐀 𝐏ᴀɴᴇʟ 𝐓ᴏ 𝐕ɪᴇᴡ 𝐃ᴇᴛᴀɪʟꜱ.", reply_markup=markup, parse_mode="HTML")

def view_panel_details(call):
    chat_id = str(call.message.chat.id)
    idx = int(call.data.split('_')[2])
    db = load_db()
    panels = db["users"].get(chat_id, {}).get("my_panels", [])

    if idx < len(panels):
        p = panels[idx]
        lang = p.get('language', 'Python')
        emoji = "🐍" if "Python" in lang else "🟨"
        details = (
            "🖥️ <b>𝐏ᴀɴᴇʟ 𝐃ᴇᴛᴀɪʟꜱ</b>\n\n"
            f"👤 <b>ᴜsᴇʀɴᴀᴍᴇ:</b> <code>{p['username']}</code>\n"
            f"🔑 <b>𝐏ᴀssᴡᴏʀᴅ:</b> <code>{p.get('password', 'N/A')}</code>\n\n"
            f"🆔 <b>𝐒ᴇʀᴠᴇʀ 𝐈ᴅ:</b> <code>{p.get('server_id', 'N/A')}</code>\n"
            f"🔧 <b>𝐓ʏᴘᴇ:</b> {emoji} {lang}\n"
            f"💾 <b>𝐑ᴀᴍ:</b> {p.get('ram', '512 𝐌ʙ')}\n"
            f"💿 <b>𝐃ɪsᴄ:</b> {p.get('disk', '1 𝐆ʙ')}\n"
            f"📅 <b>𝐂ʀᴇᴀᴛᴇᴅ:</b> {p.get('created_at', 'N/A')}\n\n"
            f"🌐 <b>𝐏ᴀɴᴇʟ 𝐔ʀʟ:</b> {PANEL_URL}"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("🌐 𝐎ᴘᴇɴ 𝐏ᴀɴᴇʟ", url=PANEL_URL))
        markup.add(InlineKeyboardButton("◀️ 𝐁ᴀᴄᴋ 𝐓ᴏ 𝐌ʏ 𝐏ᴀɴᴇʟꜱ", callback_data="back_to_panels"))
        try:
            bot.edit_message_text(details, chat_id, call.message.message_id, reply_markup=markup, parse_mode="HTML")
        except Exception as e:
            print(f"Edit error: {e}")

# ==================== PROFILE & SUPPORT ====================
@bot.message_handler(func=lambda message: message.text in ['👤 Mʏ Pʀᴏꜰɪʟᴇ', '☎️ Sᴜᴩᴩᴏʀᴛ'])
def handle_menu_options(message):
    chat_id = str(message.chat.id)
    db = load_db()

    if chat_id not in db["users"]:
        bot.send_message(chat_id, "❌ 𝐍ᴏ 𝐃ᴀᴛᴀ 𝐅ᴏᴜɴᴅ. 𝐏ʟᴇᴀꜱᴇ /𝐒ᴛᴀʀᴛ 𝐚ɢᴀɪɴ.")
        return

    if message.text == '👤 Mʏ Pʀᴏꜰɪʟᴇ':
        user_data = db["users"][chat_id]
        profile_msg = (
            "╔══════════════════╗\n"
            "   👤 <b>𝐔ꜱᴇʀ 𝐏ʀᴏꜰɪʟᴇ</b>\n"
            "╚══════════════════╝\n\n"
            f"📝 <b>ɴᴀᴍᴇ:</b> {message.from_user.first_name}\n"
            f"🆔 <b>𝐔sᴇʀ 𝐈ᴅ:</b> <code>{chat_id}</code>\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            f"👥 <b>𝐓ᴏᴛᴀʟ 𝐑ᴇғᴇʀʀᴀʟs:</b> {user_data.get('referrals', 0)}\n"
            f"🚀 <b>𝐏ᴀɴᴇʟs 𝐂ʀᴇᴀᴛᴇᴅ:</b> {user_data.get('panels_created', 0)}\n"
            "━━━━━━━━━━━━━━━━━━━━\n"
            "⭐️ <b>𝐒ᴛᴀᴛᴜꜱ:</b> 𝐀ᴄᴛɪᴠᴇ ✅"
        )
        markup = InlineKeyboardMarkup()
        markup.add(InlineKeyboardButton("📁 𝐕ɪᴇᴡ 𝐌ʏ 𝐏ᴀɴᴇʟꜱ", callback_data="back_to_panels"))
        bot.send_message(chat_id, profile_msg, reply_markup=markup, parse_mode="HTML")

    elif message.text == '☎️ Sᴜᴩᴩᴏʀᴛ':
        support_msg = (
            "👋 <b>𝐇ᴇʟʟᴏ! 𝐍ᴇᴇᴅ 𝐇ᴇʟᴘ?</b>\n\n"
            "𝐈ꜰ 𝐘ᴏᴜ 𝐅ᴀᴄᴇ 𝐀ɴʏ 𝐈ꜱꜱᴜᴇꜱ 𝐖ʜɪʟᴇ 𝐂ʀᴇᴀᴛɪɴɢ 𝐀 𝐏ᴀɴᴇʟ 𝐎ʀ 𝐇ᴀᴠᴇ 𝐀ɴʏ 𝐐ᴜᴇꜱᴛɪᴏɴꜱ, "
            "𝐏ʟᴇᴀꜱᴇ 𝐂ᴏɴᴛᴀᴄᴛ 𝐎ᴜʀ 𝐀ᴅᴍɪɴ 𝐃ɪʀᴇᴄᴛʟʏ 𝐎ʀ 𝐉ᴏɪɴ 𝐎ᴜʀ 𝐒ᴜᴘᴘᴏʀᴛ 𝐂ʜᴀɴɴᴇʟ.\n\n"
            "⏳ <b>𝐑ᴇꜱᴘᴏɴꜱᴇ 𝐓ɪᴍᴇ:</b> 1-2 𝐇ᴏᴜʀꜱ"
        )
        markup = InlineKeyboardMarkup()
        markup.add(
            InlineKeyboardButton("📢 𝐒ᴜᴘᴘᴏʀᴛ 𝐂ʜᴀɴɴᴇʟ", url="https://t.me/Shadow_Vip_Group"),
            InlineKeyboardButton("👨‍💻 𝐂ᴏɴᴛᴀᴄᴛ 𝐀ᴅᴍɪɴ", url="https://t.me/ShadowVipContact_bot")
        )
        bot.send_message(chat_id, support_msg, reply_markup=markup, parse_mode="HTML")

# ==================== REFER & EARN ====================
@bot.message_handler(func=lambda m: m.text == '🔗 Rᴇꜰᴇʀ & Eᴀʀɴ')
def refer_earn(message):
    link = f"https://t.me/{bot.get_me().username}?start=ref_{message.chat.id}"
    bot.send_message(
        message.chat.id,
        f"📢 <b>Referral Program</b>\n\n"
        f"🔗 Your Link:\n<code>{link}</code>\n\n"
        f"Refer <b>{REQUIRED_REFERRALS}</b> friends to unlock Panel Creation!",
        parse_mode="HTML"
    )

# ==================== CALLBACK HANDLER ====================
@bot.callback_query_handler(func=lambda call: True)
def handle_all_callbacks(call):
    chat_id = call.message.chat.id
    user_id = call.from_user.id

    # Admin callbacks handled separately above (startswith admin_)
    if call.data.startswith("admin_"):
        return  # handled by admin handler above

    if call.data == "verify":
        if is_user_joined(user_id):
            bot.delete_message(chat_id, call.message.message_id)
            show_main_menu(chat_id, user_id, call.from_user.first_name)
        else:
            bot.answer_callback_query(call.id, "❌ 𝐉ᴏɪɴ 𝐀ʟʟ 𝐂ʜᴀɴɴᴇʟꜱ 𝐅ɪʀꜱᴛ!", show_alert=True)

    elif call.data == "back_to_menu":
        bot.delete_message(chat_id, call.message.message_id)
        show_main_menu(chat_id, user_id, call.from_user.first_name)

    elif call.data == "back_to_panels":
        bot.delete_message(chat_id, call.message.message_id)
        my_panels_menu(call.message)

    elif call.data.startswith("view_panel_"):
        view_panel_details(call)

# ==================== HELPER ====================
def generate_server_id(length=6):
    characters = string.ascii_uppercase + string.digits
    return ''.join(random.choice(characters) for _ in range(length))

# ==================== MAIN ====================
if __name__ == "__main__":
    print("╔════════════════════════════════╗")
    print("║   𝐒ʜᴀᴅᴏᴡ 𝐏ᴀɴᴇʟ 𝐁ᴏᴛ - 𝐒ᴛᴀʀᴛᴇᴅ   ║")
    print("╚════════════════════════════════╝")
    print(f"✅ Owner ID: {OWNER_ID}")
    print(f"✅ Force Channels: {len(FORCE_CHATS)}")
    print(f"✅ Backup Channel: {BACKUP_CHANNEL_ID or '𝐍ᴏᴛ 𝐒ᴇᴛ'}")
    print("🚀 𝐁ᴏᴛ 𝐢ꜱ 𝐫ᴜɴɴɪɴɢ...")
    while True:
        try:
            bot.polling(none_stop=True, timeout=60, long_polling_timeout=20)
        except Exception as e:
            print(f"Error: {e}")
            time.sleep(5)
