# BotHost Firebase Persistent 24/7

Fixed:
- Users saved in Firebase: hosting/users
- Users sync from Firebase on login/dashboard/watchdog
- Uploaded .py/.zip backup saved in Firebase
- Projects restore from Firebase after Render restart
- Watchdog restarts autostart bots every 20 seconds
- API key: NEXA

Render:
Root Directory: empty
Build Command: pip install -r requirements.txt
Start Command: python app.py

Important:
Realtime Database is okay for small files. Large ZIP files need Render Disk or Firebase Storage.
Render Free can sleep; for true 24/7 use paid Render/VPS or ping /keepalive.
